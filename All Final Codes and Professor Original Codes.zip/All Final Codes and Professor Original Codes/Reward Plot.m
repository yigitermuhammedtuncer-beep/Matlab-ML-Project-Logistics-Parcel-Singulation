% 1. Upload statisticse
load('trainingStats.mat');

% 2. Open a new graphics window (We are making the background black)
figure('Color', 'k'); 

% Raw episode rewards are drawn in light blue.
plot(trainingStats.EpisodeIndex, trainingStats.EpisodeReward, 'Color', [0.6 0.8 1], 'LineWidth', 1);
hold on;

% Average Reward is highlighted in bold blue.
plot(trainingStats.EpisodeIndex, trainingStats.AverageReward, 'Color', [0.2 0.5 1], 'LineWidth', 2);

% 3. Make the axes and headings WHITE ('w').
xlabel('Episode Number', 'FontWeight', 'bold', 'Color', 'w');
ylabel('Reward', 'FontWeight', 'bold', 'Color', 'w');
title('PPO Agent Training Convergence', 'FontWeight', 'bold', 'Color', 'w');

% Make the text "Legend" white and the background transparent ('none').
legend('Episode Reward', 'Average Reward (Window=100)', 'Location', 'southeast', 'TextColor', 'w', 'Color', 'none');
grid on;

% 4.Make the four-sided frame, numbers, and axis lines WHITE.
ax = gca; 
set(ax, 'Color', 'k'); % The graphic's background is also black.
set(ax, 'XColor', 'w', 'YColor', 'w', 'LineWidth', 1); % Numbers and center lines are white.
box on;