load('simulation_log eleventh training with more boxes.mat');

v = VideoWriter('AMS_Video.mp4', 'MPEG-4');
v.FrameRate = 30;
v.Quality = 100; % Let's maximize quality.
open(v);

colors = lines(10);
fig = figure('Color','w'); 
set(fig, 'Position', [220 80 500 720]); 

% --- AXIS ADJUSTMENTS AND BLACK FONT CORRECTION ---
ax = gca;
% We are making the axes and values ​​BLACK using the XColor and YColor properties.
set(ax, 'Color', 'w', 'XColor', 'k', 'YColor', 'k'); 
hold on; 
axis equal; 
box on;
xlim([0 1]); 
ylim([0 2]);
xlabel('x [m]', 'Color', 'k', 'FontWeight', 'bold'); 
ylabel('y [m]', 'Color', 'k', 'FontWeight', 'bold');
title('AMS sorting environment - simple view', 'Color', 'k', 'FontWeight', 'bold');

% ---ACCURACY CALCULATION VARIABLES ---
maxBoxes = 10;
evalTopRecorded = false(maxBoxes, 1);
evalOrder = [];
evalGaps = [];
evalSuccessCount = 0;
dt = 0.01; % Simulation time step

skip_step = 4; % Jump coefficient
for t = 1:skip_step:size(x_log, 1)
    cla; %clear screen
    % 1. Outfeed Treadmill
    rectangle('Position', [0, 1.0, 1.0, 1.0], 'FaceColor', [0.92 0.92 0.92], 'EdgeColor', 'none');
    
    % 2. AMS Matrix
    rectangle('Position', [0, 0, 1.0, 1.0], 'FaceColor', [1 1 1], 'EdgeColor', [0 0 0], 'LineWidth', 1.5);
    
    % 3. Grid Lines 
    for val = 0.2:0.2:0.8
        line([0 1], [val val], 'Color', [0 0 0], 'LineWidth', 1.0); 
        line([val val], [0 1], 'Color', [0 0 0], 'LineWidth', 1.0); 
    end
    
    % 4. AMS Exit Line
    line([0 1], [1.0 1.0], 'LineWidth', 2.5, 'LineStyle', '--', 'Color', [0.20 0.20 0.20]);
    
    % 5. Evaluation Liine 
    line([0 1], [2.0 2.0], 'LineWidth', 3.0, 'LineStyle', '-', 'Color', [0.85 0.10 0.10]);
    
    % --- 6. INSTANTANEOUS ACCURACY CALCULATION ---
    newIdx = [];
    newTop = [];
    for k = 1:maxBoxes
        if ~evalTopRecorded(k) && x_log(t,k) > 0 && y_log(t,k) > 0 && d_log(t,k) > 0
            yTop = y_log(t,k) + d_log(t,k)/2;
            if yTop >= 2.0 % If the box has passed the evaluation line
                newIdx(end+1) = k;
                newTop(end+1) = yTop;
            end
        end
    end
    
    if ~isempty(newIdx)
        [~, ord] = sort(newTop, 'descend');
        newIdx = newIdx(ord);
        for ii = 1:length(newIdx)
            curr = newIdx(ii);
            evalTopRecorded(curr) = true;
            if ~isempty(evalOrder)
                prev = evalOrder(end);
                bottomPrevious = y_log(t,prev) - d_log(t,prev)/2;
                topCurrent = y_log(t,curr) + d_log(t,curr)/2;
                gap = bottomPrevious - topCurrent;
                evalGaps(end+1) = gap;
                if gap > 0
                    evalSuccessCount = evalSuccessCount + 1;
                end
            end
            evalOrder(end+1) = curr;
        end
    end
    
    nPairs = length(evalGaps);
    if nPairs == 0
        accText = 'n/a';
        gapText = 'n/a';
    else
        accuracy = 100 * evalSuccessCount / nPairs;
        accText = sprintf('%.1f%%', accuracy);
        lastGap = evalGaps(end);
        gapText = sprintf('%.3f m', lastGap);
    end
    
    sim_time = t * dt;
    generated_count = sum(d_log(t,:) > 0);
    
    % 7. Static Text and Arrows
    text(0.02, 1.03, 'AMS exit', 'FontSize', 9, 'FontWeight', 'bold', 'Color', [0.20 0.20 0.20]);
    text(0.02, 1.95, 'accuracy evaluation line: 1 m after AMS exit', 'FontSize', 9, 'FontWeight', 'bold', 'Color', [0.85 0.10 0.10]);
    text(0.02, 1.50, 'outfeed treadmill: v = 1.90 m/s', 'FontSize', 9, 'Color', [0.25 0.25 0.25]);
    
    % Dynamic Information Panels (with White Background)
    info1 = sprintf('t = %.2f s | generated = %d/%d | evaluated pairs = %d', sim_time, generated_count, maxBoxes, nPairs);
    info2 = sprintf('accuracy @ yExit + 1 m: %s | last gap = %s', accText, gapText);
    
    text(0.02, 1.82, info1, 'FontSize', 10, 'FontWeight', 'bold', 'BackgroundColor', [1 1 1], 'Margin', 3, 'Color', [0.6 0.6 0.6]);
    text(0.02, 1.71, info2, 'FontSize', 10, 'FontWeight', 'bold', 'BackgroundColor', [1 1 1], 'Margin', 3, 'Color', [0.6 0.6 0.6]);

    for xx = linspace(0.20, 0.80, 3)
        quiver(xx, 1.15, 0, 0.16, 0, 'LineWidth', 1.0, 'MaxHeadSize', 1.5, 'Color', [0.35 0.35 0.35]);
    end

    % 8. Draw the boxes 
    for k = 1:10
        if x_log(t,k) > 0 && y_log(t,k) > 0 && d_log(t,k) > 0
            d = d_log(t,k);
            xLeft = x_log(t,k) - d/2;
            yBottom = y_log(t,k) - d/2;
            
            rectangle('Position', [xLeft, yBottom, d, d], ...
                'FaceColor', colors(k,:), ...
                'EdgeColor', 'k', 'LineWidth', 1.2);
                
            text(x_log(t,k), y_log(t,k), num2str(k), ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                'Color', 'w', 'FontWeight', 'bold', 'FontSize', 8);
        end
    end
    
    drawnow limitrate;
    writeVideo(v, getframe(fig));
end

close(v);
disp('Video hazir: AMS_Video.mp4');